=== three-object-viewer-three-icosa ===
Contributors: antpb
Donate link: http://example.com/
Tags: comments, spam
Tested up to: 6.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

This plugin is used to add openbrush support to the Three Object Viewer plugin. Simply install this plugin and add an environment block to your space. Note: Openbrush objects are currently only supported in the Model Block in the Enviornment innerblocks of Three Object Viewer. 

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the release zip through your plugin uploader screen
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add an environment block to your post.
4. Select a model to be the base mesh of your environment.
5. Add a 'Model Block'
6. Select an openbrush glb file
7. Publish

= 0.1 =
Initial version.
